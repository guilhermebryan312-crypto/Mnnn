package com.slifx.aieditor

import androidx.activity.ComponentActivity
import android.content.Context
import android.content.Intent
import android.content.ContentValues
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Environment
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.C
import androidx.media3.common.audio.SpeedProvider
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Effects
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.Contrast
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ProgressHolder
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.concurrent.Executors
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {
    private val bg = Color.rgb(10, 9, 18)
    private val panel = Color.rgb(25, 22, 38)
    private val panel2 = Color.rgb(35, 29, 53)
    private val purple = Color.rgb(151, 111, 255)
    private val pale = Color.rgb(220, 211, 255)
    private val muted = Color.rgb(165, 158, 184)
    private val white = Color.WHITE
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var prompt: EditText
    private lateinit var apiKey: EditText
    private lateinit var style: Spinner
    private lateinit var saveKeySwitch: Switch
    private lateinit var progressBar: ProgressBar
    private lateinit var progressText: TextView
    private lateinit var etaText: TextView
    private lateinit var routeText: TextView
    private val mainHandler = Handler(Looper.getMainLooper())
    private var exportStartedAt = 0L
    private var activeRoute = 0
        private var exportOutput: File? = null
    private var exportInProgress = false
    private val progressHolder = ProgressHolder()
    private val progressTicker = object : Runnable {
        override fun run() {
            val current = transformer ?: return
            if (!exportInProgress) return
            try {
                val state = current.getProgress(progressHolder)
                if (state == Transformer.PROGRESS_STATE_AVAILABLE) {
                    val percent = progressHolder.progress.coerceIn(0, 100)
                                        progressBar.progress = percent
                    progressText.text = "${percent}% da montagem/exportação"
                    val elapsed = (System.currentTimeMillis() - exportStartedAt).coerceAtLeast(1L)
                    val eta = if (percent in 1..99) ((elapsed.toDouble() * (100 - percent) / percent) / 1000.0).toLong() else 0L
                    etaText.text = if (percent >= 100) "Finalizando arquivo…" else "Tempo estimado restante: ${formatTime(eta)}"
                } else {
                    etaText.text = "Calculando tempo restante…"
                }
            } catch (_: Exception) {
                etaText.text = "Progresso indisponível nesta etapa"
            }
            mainHandler.postDelayed(this, 500)
        }
    }
    private val videoUris = mutableListOf<Uri>()
    private lateinit var mediaSelectionText: TextView
    private lateinit var outputRatio: Spinner
    private lateinit var colorFilter: Spinner
    private lateinit var speedSpinner: Spinner
    private var audioUri: Uri? = null
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            videoUris.clear()
            videoUris.addAll(uris)
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            }
            mediaSelectionText.text = "${videoUris.size} clipe(s) selecionado(s) • ordem da seleção preservada"
            status.text = "Clipes carregados • sequência pronta para montar"
        }
    }
    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let {
            audioUri = it
            try { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            status.text = "Trilha de fundo selecionada"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        setContentView(buildScreen())
        loadSavedKey()
    }

    private fun buildScreen(): View {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg); clipToPadding = false }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(32))
        }
        scroll.addView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = column()
        brand.addView(label("SLIFX", 30, white, true))
        brand.addView(label("AI EDITOR  /  CREATIVE STUDIO", 10, purple, true))
        top.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(pill("BETA  0.5", purple))
        root.addView(top)
        root.addView(space(22))

        val hero = card()
        hero.addView(label("TRANSFORME SUA IDEIA", 11, pale, true))
        hero.addView(label("Sua próxima edit começa aqui.", 25, white, true))
        hero.addView(label("Descreva o resultado. O SLIFX prepara um plano criativo e exporta seu vídeo.", 14, muted, false))
        hero.addView(space(10))
        hero.addView(pill("✦  AI-ASSISTED WORKFLOW", purple))
        root.addView(hero)
        root.addView(space(16))

        section(root, "01", "DIREÇÃO CRIATIVA", "Defina personagem, clima e identidade visual.")
        prompt = EditText(this).apply {
            hint = "Ex.: Subaru Natsuki — edit emocional que cresce até um drop intenso, cortes rápidos, velocity pontual, shakes sincronizados e color grading azul noturno..."
            setHintTextColor(muted); setTextColor(white); textSize = 14f
            minLines = 4; gravity = Gravity.TOP
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel2)
        }
        root.addView(prompt, LinearLayout.LayoutParams(-1, dp(132)))
        root.addView(space(10))
        style = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Anime AMV / TikTok", "Velocity + beat sync", "Emotional / cinematic", "Phonk / aggressive", "3D / impact edit", "Clean / minimal", "Storytelling / character edit"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        root.addView(label("PRESET DE ESTILO", 10, pale, true))
        root.addView(style)
        root.addView(space(18))

        section(root, "02", "MÍDIA DO PROJETO", "Escolha o material que você tem direito de usar.")
        val mediaCard = card()
        mediaCard.addView(btn("＋  Selecionar vários clipes", false) { pickVideo.launch(arrayOf("video/*")) })
        mediaSelectionText = label("Nenhum clipe selecionado.", 12, pale, false)
        mediaCard.addView(mediaSelectionText)
        mediaCard.addView(btn("♫  Selecionar música de fundo", false) { pickAudio.launch(arrayOf("audio/*")) })
        mediaCard.addView(label("Quando uma música for escolhida, ela será mixada como trilha principal e o áudio original dos clipes será silenciado. Sem música, o áudio original é mantido.", 11, muted, false))
        root.addView(mediaCard)
        root.addView(space(18))

        section(root, "03", "INTELIGÊNCIA ARTIFICIAL", "Ative o provedor e configure sua chave.")
        val aiCard = card()
        val aiRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val aiText = column()
        aiText.addView(label("Google Gemini", 16, white, true))
        aiText.addView(label("Planejamento criativo por API", 11, muted, false))
        aiRow.addView(aiText, LinearLayout.LayoutParams(0, -2, 1f))
        saveKeySwitch = Switch(this).apply { isChecked = true; text = "Ativo"; setTextColor(pale) }
        aiRow.addView(saveKeySwitch)
        aiCard.addView(aiRow)
        aiCard.addView(space(8))
        apiKey = EditText(this).apply {
            hint = "Cole sua chave Gemini API"
            setHintTextColor(muted); setTextColor(white); textSize = 14f
            inputType = 129
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setBackgroundColor(panel2)
        }
        aiCard.addView(apiKey, LinearLayout.LayoutParams(-1, dp(52)))
        aiCard.addView(space(6))
        aiCard.addView(btn("Salvar chave com proteção do Android", false) { saveKey() })
        aiCard.addView(label("A chave fica criptografada no armazenamento privado deste aparelho. Não cole chaves em chats, prints ou repositórios.", 11, muted, false))
        root.addView(aiCard)
        root.addView(space(18))

        section(root, "04", "FORMATO DE SAÍDA", "Escolha a proporção final da composição.")
        outputRatio = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Vertical 9:16 — TikTok / Reels / Shorts", "Quadrado 1:1", "Horizontal 16:9"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        root.addView(outputRatio)
        root.addView(space(10))
        root.addView(label("TRATAMENTO DE COR", 10, pale, true))
        colorFilter = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Natural", "Preto e branco", "Invertido", "Contraste cinematográfico"))
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        root.addView(colorFilter)
        root.addView(space(10))
        root.addView(label("VELOCIDADE GLOBAL", 10, pale, true))
        speedSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("0,75x — lento", "1,00x — normal", "1,25x — rápido", "1,50x — muito rápido"))
            setSelection(1)
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }
        root.addView(speedSpinner)
        root.addView(space(16))

        section(root, "05", "GERAR E EXPORTAR", "A IA cria o plano; o motor de mídia monta e renderiza os clipes.")
        root.addView(btn("✦  ANALISAR E CRIAR PLANO", true) { generatePlan() })
        root.addView(space(8))
        root.addView(btn("▶  MONTAR E EXPORTAR EDIT", false) { exportVideo() })
        root.addView(space(10))
        status = label("Aguardando seu projeto.", 12, pale, false)
        root.addView(status)
        root.addView(space(8))
        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(purple)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(panel2)
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(10)))
        progressText = label("0% da exportação", 12, pale, true)
        etaText = label("Tempo estimado restante: —", 11, muted, false)
        routeText = label("Rota: aguardando", 11, muted, false)
        root.addView(progressText)
        root.addView(etaText)
        root.addView(routeText)
        root.addView(space(12))
        result = label("Seu plano criativo aparecerá aqui.", 13, white, false)
        val resultCard = card()
        resultCard.addView(label("SLIFX EDIT PLAN", 10, purple, true))
        resultCard.addView(result)
        root.addView(resultCard)
        root.addView(space(18))
        root.addView(label("SLIFX AI EDITOR • BUILD 0.5.0", 10, muted, true))
        root.addView(label("Motor Media3: concatenação de vários clipes, mixagem de trilha em sequência separada, velocidade global ajustável, recorte de proporção, filtros de cor aplicados, exportação MP4 e fallback de codec. A análise automática de BPM, cortes por batida, velocity ramps por trecho, shakes, Headpop, motion blur, 3D, transições e preview de timeline ainda não estão implementados.", 11, muted, false))
        return scroll
    }

    private fun generatePlan() {
        val text = prompt.text.toString().trim()
        if (text.isBlank()) { status.text = "Descreva a edit antes de gerar o plano."; return }
        if (!saveKeySwitch.isChecked) { status.text = "Ative o Gemini para gerar o plano."; return }
        val key = apiKey.text.toString().trim().ifBlank { readKey().orEmpty() }
        if (key.isBlank()) { status.text = "Adicione sua chave Gemini API primeiro."; return }
        hideKeyboard()
        status.text = "Gemini está criando o plano…"
        val selectedStyle = style.selectedItem.toString()
        executor.execute {
            try {
                val promptText = """Você é diretor profissional de edição vertical. Crie um plano prático e detalhado para uma edit no estilo $selectedStyle.
Pedido: $text
Retorne em português, com: conceito, estrutura temporal por blocos, ritmo de cortes, transições, efeitos adequados, color grading, tipografia opcional e checklist de exportação 9:16.
Não invente que analisou arquivos ou batidas que não recebeu. Indique claramente quando algo depende de análise do vídeo/áudio. Evite efeitos aleatórios. Priorize direitos autorais e fontes autorizadas."""
                val payload = JSONObject().put("contents",
                    org.json.JSONArray().put(JSONObject().put("parts",
                        org.json.JSONArray().put(JSONObject().put("text", promptText)))))
                val conn = (URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent").openConnection() as HttpURLConnection)
                conn.requestMethod = "POST"
                conn.connectTimeout = 20000
                conn.readTimeout = 60000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.setRequestProperty("x-goog-api-key", key)
                conn.outputStream.use { it.write(payload.toString().toByteArray(StandardCharsets.UTF_8)) }
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                conn.disconnect()
                if (code !in 200..299) throw Exception("Gemini respondeu HTTP $code: ${body.take(500)}")
                val json = JSONObject(body)
                val answer = json.getJSONArray("candidates").getJSONObject(0)
                    .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
                runOnUiThread {
                    result.text = answer
                    status.text = "Plano criado. Confira as etapas antes de exportar."
                }
            } catch (e: Exception) {
                val fallback = """PLANO LOCAL DE CONTINGÊNCIA — Gemini indisponível (${e.message ?: "falha de conexão"}).

Rota alternativa: edição manual guiada.
1. Separe o vídeo em introdução, desenvolvimento e clímax.
2. Marque manualmente os pontos fortes da música; a análise automática de BPM ainda não está disponível.
3. Use cortes simples nos momentos de impacto e preserve pausas nas cenas emocionais.
4. Aplique poucos efeitos por vez e confira a legibilidade em tela de celular.
5. Exporte uma prévia curta antes da versão final.

Este plano é um fallback local, não uma análise do seu arquivo."""
                runOnUiThread {
                    result.text = fallback
                    status.text = "Gemini falhou. Plano alternativo local criado para você não ficar travado."
                }
            }
        }
    }

    private fun exportVideo() {
        if (videoUris.isEmpty()) { status.text = "Selecione pelo menos um clipe primeiro."; return }
        if (exportInProgress) { status.text = "Já existe uma exportação em andamento."; return }
        exportOutput = File(getExternalFilesDir(null), "SLIFX_${System.currentTimeMillis()}.mp4")
        activeRoute = 0
        progressBar.progress = 0
        progressText.text = "0% da montagem"
        etaText.text = "Calculando tempo restante…"
        exportInProgress = true
        startExportRoute()
    }

    private fun buildComposition(): Composition {
        val ratio = when (outputRatio.selectedItemPosition) {
            1 -> 1f
            2 -> 16f / 9f
            else -> 9f / 16f
        }
        val crop = Presentation.createForAspectRatio(
            ratio,
            Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP
        )
        val selectedSpeed = when (speedSpinner.selectedItemPosition) {
            0 -> 0.75f
            2 -> 1.25f
            3 -> 1.5f
            else -> 1.0f
        }
        val editedClips = videoUris.map { uri ->
            val itemBuilder = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            // If a replacement soundtrack exists, remove clip audio to avoid doubling voices/music.
            if (audioUri != null) itemBuilder.setRemoveAudio(true)
            if (selectedSpeed != 1.0f) {
                val constantSpeed = object : SpeedProvider {
                    override fun getSpeed(timeUs: Long): Float = selectedSpeed
                    override fun getNextSpeedChangeTimeUs(timeUs: Long): Long = C.TIME_UNSET
                }
                itemBuilder.setSpeed(constantSpeed)
            }
            itemBuilder.build()
        }
        val videoSequence = EditedMediaItemSequence.withAudioAndVideoFrom(editedClips)
        val sequences = mutableListOf(videoSequence)
        audioUri?.let { music ->
            val musicItem = EditedMediaItem.Builder(MediaItem.fromUri(music)).build()
            val musicSequence = EditedMediaItemSequence.withAudioFrom(listOf(musicItem))
                .buildUpon()
                .setIsLooping(true)
                .build()
            sequences.add(musicSequence)
        }
        val videoEffects = mutableListOf<androidx.media3.common.Effect>(crop)
        when (colorFilter.selectedItemPosition) {
            1 -> videoEffects.add(RgbFilter.createGrayscaleFilter())
            2 -> videoEffects.add(RgbFilter.createInvertedFilter())
            3 -> videoEffects.add(Contrast(0.22f))
        }
        return Composition.Builder(sequences)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()
    }

    // Rota 1: H.264/AAC preferidos. Rota 2: codecs automáticos do aparelho.
    // Ambas renderizam a mesma composição; o fallback é de compatibilidade do encoder.
    private fun startExportRoute() {
        val out = exportOutput ?: return
        exportStartedAt = System.currentTimeMillis()
        val routeName = if (activeRoute == 0) "1/2 — H.264 + AAC preferidos" else "2/2 — codecs automáticos (fallback)"
        status.text = "Montando ${videoUris.size} clipe(s) e exportando…"
        routeText.text = "Rota ativa: $routeName"
        etaText.text = "Calculando tempo restante…"
        try {
            try { transformer?.cancel() } catch (_: Exception) { }
            val builder = Transformer.Builder(this)
            if (activeRoute == 0) {
                builder.setVideoMimeType("video/avc")
                builder.setAudioMimeType("audio/mp4a-latm")
            }
            transformer = builder.addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    mainHandler.removeCallbacks(progressTicker)
                    executor.execute {
                        try {
                            val values = ContentValues().apply {
                                put(MediaStore.Video.Media.DISPLAY_NAME, out.name)
                                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/SLIFX")
                                put(MediaStore.Video.Media.IS_PENDING, 1)
                            }
                            val savedUri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                                ?: throw Exception("Não foi possível criar o arquivo na galeria.")
                            contentResolver.openOutputStream(savedUri)?.use { output ->
                                out.inputStream().use { input -> input.copyTo(output) }
                            } ?: throw Exception("Não foi possível gravar o MP4.")
                            val ready = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                            contentResolver.update(savedUri, ready, null, null)
                            out.delete()
                            runOnUiThread {
                                exportInProgress = false
                                progressBar.progress = 100
                                progressText.text = "100% da montagem/exportação"
                                etaText.text = "Concluído!"
                                routeText.text = "Finalizado pela rota $routeName"
                                status.text = "${videoUris.size} clipe(s) exportados em Filmes/SLIFX"
                                Toast.makeText(this@MainActivity, "MP4 salvo em Filmes/SLIFX", Toast.LENGTH_LONG).show()
                            }
                        } catch (e: Exception) {
                            runOnUiThread {
                                exportInProgress = false
                                status.text = "Exportado, mas não foi possível publicar na galeria: ${e.message}"
                                etaText.text = "Renderização concluída; falha ao salvar na galeria."
                            }
                        }
                    }
                }
                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    mainHandler.removeCallbacks(progressTicker)
                    if (activeRoute == 0) {
                        runOnUiThread {
                            status.text = "Rota 1 falhou. Tentando rota alternativa…"
                            routeText.text = "Fallback: codecs automáticos"
                            progressBar.progress = 0
                            progressText.text = "Reiniciando em 0% na rota 2"
                            activeRoute = 1
                            exportOutput?.delete()
                            startExportRoute()
                        }
                    } else {
                        runOnUiThread {
                            exportInProgress = false
                            status.text = "As duas rotas de exportação falharam: ${exportException.message}"
                            etaText.text = "Não foi possível estimar conclusão porque a exportação falhou."
                            routeText.text = "Rotas tentadas: H.264/AAC e codecs automáticos"
                        }
                    }
                }
            }).build()
            transformer?.start(buildComposition(), out.absolutePath)
            mainHandler.post(progressTicker)
        } catch (e: Exception) {
            mainHandler.removeCallbacks(progressTicker)
            if (activeRoute == 0) {
                activeRoute = 1
                out.delete()
                status.text = "Falha ao iniciar rota 1; tentando codecs automáticos…"
                startExportRoute()
            } else {
                exportInProgress = false
                status.text = "Não foi possível iniciar nenhuma rota: ${e.message}"
            }
        }
    }

    private fun formatTime(seconds: Long): String {
        val safe = seconds.coerceAtLeast(0)
        val minutes = safe / 60
        val secs = safe % 60
        return if (minutes > 0) "${minutes} min ${secs} s" else "${secs} s"
    }

    private fun saveKey() {
        val key = apiKey.text.toString().trim()
        if (key.isBlank()) { status.text = "Cole uma chave antes de salvar."; return }
        try {
            val encrypted = encrypt(key)
            getSharedPreferences("slifx_secure", MODE_PRIVATE).edit()
                .putString("key_iv", android.util.Base64.encodeToString(encrypted.first, android.util.Base64.NO_WRAP))
                .putString("key_data", android.util.Base64.encodeToString(encrypted.second, android.util.Base64.NO_WRAP))
                .apply()
            status.text = "Chave salva de forma criptografada neste aparelho."
            apiKey.setText("")
        } catch (e: Exception) {
            status.text = "Não foi possível proteger a chave: ${e.message}"
        }
    }

    private fun loadSavedKey() {
        if (readKey() != null) status.text = "Chave Gemini protegida já configurada."
    }
    private fun readKey(): String? = try {
        val p = getSharedPreferences("slifx_secure", MODE_PRIVATE)
        val iv = android.util.Base64.decode(p.getString("key_iv", null), android.util.Base64.NO_WRAP)
        val data = android.util.Base64.decode(p.getString("key_data", null), android.util.Base64.NO_WRAP)
        decrypt(iv, data)
    } catch (_: Exception) { null }

    private fun secretKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = ks.getKey("slifx_aes_key", null) as? SecretKey
        if (existing != null) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(KeyGenParameterSpec.Builder("slifx_aes_key",
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setRandomizedEncryptionRequired(true).build())
        return generator.generateKey()
    }
    private fun encrypt(value: String): Pair<ByteArray, ByteArray> {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, secretKey())
        return Pair(cipher.iv, cipher.doFinal(value.toByteArray(StandardCharsets.UTF_8)))
    }
    private fun decrypt(iv: ByteArray, data: ByteArray): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secretKey(), GCMParameterSpec(128, iv))
        return String(cipher.doFinal(data), StandardCharsets.UTF_8)
    }

    private fun hideKeyboard() {
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(prompt.windowToken, 0)
    }
    private fun section(parent: LinearLayout, num: String, title: String, sub: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(pill(num, purple))
        val c = column().apply {
            addView(label(title, 15, white, true))
            addView(label(sub, 11, muted, false))
        }
        val lp = LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) }
        row.addView(c, lp)
        parent.addView(row)
        parent.addView(space(10))
    }
    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        setBackgroundColor(panel)
    }
    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
    private fun label(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = s; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        setPadding(0, dp(2), 0, dp(4))
    }
    private fun pill(s: String, color: Int) = TextView(this).apply {
        text = s; textSize = 10f; typeface = Typeface.DEFAULT_BOLD; setTextColor(white)
        setPadding(dp(10), dp(7), dp(10), dp(7)); setBackgroundColor(Color.rgb(66, 48, 103))
    }
    private fun btn(textValue: String, primary: Boolean, action: () -> Unit) = Button(this).apply {
        text = textValue; isAllCaps = false; textSize = 13f; typeface = Typeface.DEFAULT_BOLD
        setTextColor(white)
        setBackgroundColor(if (primary) Color.rgb(112, 75, 210) else panel2)
        minHeight = dp(50)
        setOnClickListener { action() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(6); bottomMargin = dp(6) }
    }
    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        mainHandler.removeCallbacks(progressTicker)
        transformer?.cancel()
        executor.shutdown()
        super.onDestroy()
    }
}
