# 0.4.0
- Adicionado indicador de progresso da exportação com percentual consultado no Media3 Transformer.
- Adicionada estimativa de tempo restante baseada no tempo decorrido e no percentual real.
- Adicionada segunda rota de exportação com seleção automática de codecs se a rota H.264/AAC falhar.
- Adicionado plano local de contingência quando a API Gemini falhar.
- A interface e o README deixam explícito que isso ainda não é uma engine de edição automática multi-clipe/efeitos.
