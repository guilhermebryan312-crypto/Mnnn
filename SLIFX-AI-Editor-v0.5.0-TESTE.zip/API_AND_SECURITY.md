# API e segurança

- Gemini é opcional e usado apenas para gerar um plano textual.
- Não coloque chaves API no código-fonte, no GitHub, em prints ou em mensagens.
- A chave Gemini é armazenada no armazenamento privado do app, cifrada com AES/GCM e uma chave do Android Keystore.
- A integração com Gemini exige uma chave própria e conectividade de rede.
- Não há integração com serviços que proíbem menores de idade ou que exijam contornar regras de acesso.
- A exportação de mídia é local no aparelho; os vídeos não são enviados ao Gemini pelo código desta versão.
