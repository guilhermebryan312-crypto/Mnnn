# SLIFX AI Editor 0.5.0 — build de teste

Aplicativo Android nativo em Kotlin, com exportação baseada em AndroidX Media3 Transformer.

## O que esta versão realmente faz

- Seleciona vários vídeos de uma vez e preserva a ordem retornada pelo seletor do Android.
- Concatena os clipes em uma única sequência de vídeo.
- Permite selecionar uma música de fundo; quando selecionada, o áudio dos clipes é removido e a música é repetida até o fim da sequência.
- Sem música externa, preserva o áudio original dos clipes.
- Exporta com recorte central para 9:16, 1:1 ou 16:9.
- Aplica um filtro global real: natural, preto e branco, invertido ou contraste.
- Permite velocidade constante global: 0,75x, 1x, 1,25x ou 1,5x.
- Mostra progresso e estimativa de tempo restante da exportação Media3.
- Tenta H.264/AAC e, se a rota falhar, tenta novamente com seleção automática de codecs.
- Salva o MP4 em `Filmes/SLIFX`.
- Mantém integração opcional com Gemini para gerar um plano textual. A chave é guardada cifrada com Android Keystore.

## O que ainda NÃO faz

- Não detecta BPM nem os pontos de batida automaticamente.
- Não cria cortes dinâmicos por batida nem velocity ramp por trechos.
- Não aplica shakes, Headpop, motion blur, efeitos 3D, transições ou máscaras.
- Não tem timeline visual editável, preview em tempo real, keyframes ou edição por camada.
- O plano do Gemini é orientação textual; não controla automaticamente a timeline.
- A velocidade é constante em todos os clipes, não uma curva de velocity.
- O enquadramento vertical é um crop central; ainda não há reposicionamento manual do assunto.
- A saída depende dos codecs e da memória disponíveis no aparelho. 4K não é garantido.

## Como testar no celular

1. Envie o conteúdo desta pasta para a raiz de um repositório GitHub (não envie apenas o ZIP dentro do repositório).
2. Abra a aba **Actions** e execute o workflow **Build SLIFX AI Editor APK** (ou faça push para `main`).
3. Aguarde o workflow terminar e abra o artefato `SLIFX-AI-Editor-APK`.
4. Baixe o APK debug e instale no Android. O Android pode pedir autorização para instalar apps obtidos fora da Play Store.
5. Selecione 2 ou mais clipes curtos, opcionalmente uma música, escolha 9:16 e um filtro, e exporte.
6. Confira o MP4 em `Galeria/Filmes/SLIFX`.

## Build local

Requer JDK 17, Android SDK 35 e Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Observação de teste

Este ambiente não tem Android SDK/Gradle em cache nem acesso de rede para baixar dependências, então não foi possível compilar o APK aqui. O ZIP contém o projeto-fonte e workflow de CI; a compilação precisa ser confirmada pelo GitHub Actions antes de considerar o APK validado.
