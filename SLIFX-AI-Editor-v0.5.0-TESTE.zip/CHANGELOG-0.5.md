# 0.5.0 — 2026-11-22

- Adicionada seleção de múltiplos clipes.
- Adicionada composição Media3 com clipes em sequência.
- Adicionada faixa de música de fundo repetida até o fim da sequência; áudio original dos clipes é removido quando música externa está selecionada.
- Adicionados formatos 9:16, 1:1 e 16:9 com crop central.
- Adicionados filtros de cor natural, preto e branco, invertido e contraste.
- Adicionada velocidade global constante de 0,75x a 1,5x.
- Mantidos progresso/ETA e fallback de codec.
- Atualizada documentação com recursos reais e limitações.

## Limitações conhecidas

Sem BPM automático, cortes por batida, velocity ramp por trecho, shakes, Headpop, motion blur, 3D, transições, preview ou timeline visual. O APK ainda precisa passar pelo GitHub Actions; não foi compilado neste ambiente.
